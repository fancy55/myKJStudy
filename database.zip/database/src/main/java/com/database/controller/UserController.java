package com.database.controller;

import com.alibaba.fastjson.JSONArray;
import com.database.jdbc.*;
import com.database.jdbc.abstact.DataSource;
import com.database.jdbc.inteface.Session;
import com.database.model.User;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
public class UserController {
    DataSource dataSource = new BasicDataSource();
    JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);
    Session session = new SessionImpl(jdbcTemplate);
    Map<String, Object> map = new HashMap<>();

    @GetMapping("get/by/uid")
    public Map<String, Object> getByUid(String uid){
        User user = (User)session.load(User.class, uid);
        map.put("msg",user);
        return map;
    }

    @GetMapping("get/all")
    public Map<String, Object> getAll(){
        List<Object> user = new ArrayList<Object>();
         user = session.load(User.class);
        map.put("msg",user);
        return map;
    }

    @PostMapping("insert")
    @ResponseBody
    public Object insert(String msg){
        User user = JSONArray.parseObject(msg, User.class);
        return session.load(User.class, user);
    }

    @PostMapping("delete")
    public void deleteByUid(String uid){
        session.loadD(User.class, uid);
    }

    @PostMapping("update")
    public void updateByUid(String msg){
        User user = JSONArray.parseObject(msg, User.class);
        session.loadU(User.class, user);
    }

}
