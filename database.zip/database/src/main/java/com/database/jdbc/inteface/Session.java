package com.database.jdbc.inteface;

import com.database.model.User;

import java.io.Serializable;
import java.util.List;

public interface Session {
	public Object load(Class clazz, Serializable uid); //根据uid查
	public Object loadU(Class clazz, User user);  //更新
	public Object load(Class clazz, User user); //插入
	public Object loadD(Class clazz, Serializable uid); //删除
	public List<Object> load(Class clazz); //查全部
}
