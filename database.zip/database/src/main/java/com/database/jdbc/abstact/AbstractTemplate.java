package com.database.jdbc.abstact;

import com.database.jdbc.inteface.PreparedStatementSetter;
import com.database.jdbc.inteface.RowMapper;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

public abstract class AbstractTemplate {
	private DataSource dataSource;
	public AbstractTemplate(DataSource dataSource) {
		this.dataSource = dataSource;
	}
	public DataSource getDataSource() {
		return dataSource;
	}
	public void setDataSource(DataSource dataSource) {
		this.dataSource = dataSource;
	}

	public Object query(String sql, PreparedStatementSetter setter, RowMapper<Object,ResultSet> rowMapper) {
		Connection conn = null;
		Object obj = null;
		try {
			conn = this.dataSource.getConnection();
			PreparedStatement preparedStatement = conn.prepareStatement(sql);
			setter.setParameter(preparedStatement);
			ResultSet rs = preparedStatement.executeQuery();
			obj = rowMapper.mapRow(rs);
		}catch(Exception ex) {
			ex.printStackTrace();
		}finally {
			try {
				if(conn != null)
					conn.close();
			} catch (SQLException e) {
				throw new RuntimeException(e.getMessage());
			}
		}
		return obj;
	}

	public List<Object> query(String sql, RowMapper<List<Object>, ResultSet> rowMapper) {
		Connection conn = null;
		List<Object> obj = null;
		try {
			conn = this.dataSource.getConnection();
			PreparedStatement preparedStatement = conn.prepareStatement(sql);
			ResultSet rs1 = preparedStatement.executeQuery();
			obj = rowMapper.mapRow(rs1);
		}catch(Exception ex) {
			ex.printStackTrace();
		}finally {
			try {
				if(conn != null)
					conn.close();
			} catch (SQLException e) {
				throw new RuntimeException(e.getMessage());
			}
		}
		return obj;
	}

	public Object query(String sql, PreparedStatementSetter setter) {
		Connection conn = null;
		Object res = null;
		try {
			conn = this.dataSource.getConnection();
			PreparedStatement preparedStatement = conn.prepareStatement(sql);
			setter.setParameter(preparedStatement);
			res = preparedStatement.executeUpdate();
		}catch(Exception ex) {
			ex.printStackTrace();
		}finally {
			try {
				if(conn != null)
					conn.close();
			} catch (SQLException e) {
				throw new RuntimeException(e.getMessage());
			}
		}
		return res;
	}
}
