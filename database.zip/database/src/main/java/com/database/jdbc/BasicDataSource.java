package com.database.jdbc;

import com.database.jdbc.abstact.DataSource;

import java.io.FileInputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.util.Properties;

public class BasicDataSource extends DataSource {
	Properties props = new Properties();

	public BasicDataSource() {
		try {
			props.load(new FileInputStream("src/main/resources/public/config.properties"));
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Override
	public Connection getConnection() {
		try {
			Class.forName(props.getProperty("driverClass"));
			Connection conn = DriverManager.getConnection(props.getProperty("url"), props.getProperty("username"),
					props.getProperty("password"));
			return conn;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

}
