package com.database.jdbc.inteface;

import java.sql.ResultSet;

public interface RowMapper<T,M> {
	T mapRow(M rs) throws Exception;
}
