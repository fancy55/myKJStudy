package com.database.jdbc;

import com.database.jdbc.abstact.AbstractTemplate;
import com.database.jdbc.abstact.DataSource;
import java.lang.reflect.Method;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class JdbcTemplate<T> extends AbstractTemplate {
	
	public JdbcTemplate(DataSource dataSource) {
		super(dataSource);
	}

	public Object queryForObject(String sql, final Object[] args, final Class clazz) {
		return this.query(sql, preparedStatement -> {
			if(args == null)return;
			System.out.println("size:"+args.length);
			for (int i = 0; i < args.length; i++) {
				try {
					preparedStatement.setObject(i + 1, args[i]);
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}, rs -> {
			Object obj = null;
			Method[] methods = clazz.getMethods();
			obj = clazz.getConstructors()[0].newInstance();  //实例化
//				System.out.println("obj:"+obj.getClass());
			try {
				int cols = rs.getMetaData().getColumnCount();
				while (rs.next()) {
					for (int i = 0; i < cols; i++) {
						String cn = rs.getMetaData().getColumnName(i + 1); // uid
//						System.out.println("cn:"+cn);
						for (Method method : methods) {
							if (method.getName().equalsIgnoreCase("set" + cn)) { // setUid
								method.invoke(obj, rs.getObject(cn));
								break;
							}
						}
					}
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
			return obj;
		});
	}

	public Object queryForObject(String sql, Object args) {
		return this.query(sql, preparedStatement -> {
			if(args == null)return;
			try {
				preparedStatement.setObject(1, args);
			} catch (SQLException e) {
				e.printStackTrace();
			}
		});
	}

	public List<Object> queryForObject(String sql ,final Class clazz) {
		return this.query(sql,  rs1 -> {
			List<Object> list = new ArrayList<Object>();
			Method[] methods = clazz.getMethods();
			try {
				int cols = rs1.getMetaData().getColumnCount();
				while (rs1.next()) {
					Object obj = clazz.getConstructors()[0].newInstance();  //实例化
					for (int i = 0; i < cols; i++) {
						String cn = rs1.getMetaData().getColumnName(i + 1); // uid/name/score
						for (Method method : methods) {
							if (method.getName().equalsIgnoreCase("set" + cn)) { // setUid/setName/setScore
								method.invoke(obj, rs1.getObject(cn));
								list.add(obj);
								break;
							}
						}
					}
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
			return list;
		});
	}

	public Object queryForObject(String sql, final Object[] args) {
		return this.query(sql, preparedStatement -> {
			if(args == null)return;
			System.out.println("size:"+args.length);
			for (int i = 0; i < args.length; i++) {
				try {
					preparedStatement.setObject(i + 1, args[i]);
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		});
	}



}
