package com.database.jdbc;

import com.database.jdbc.inteface.Session;
import com.database.model.User;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.Serializable;
import java.util.List;
import java.util.Properties;

public class SessionImpl implements Session {
	
	private JdbcTemplate jdbcTemplate;
	private Properties orm = new Properties();

	public SessionImpl(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
		try {
			orm.load(new FileInputStream("src/main/resources/public/orm.properties"));
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	private String selectByUId(Class clazz) {
		StringBuffer sb = new StringBuffer();
		sb.append("select ")
		.append(orm.getProperty("property"))
		.append(" from ")
		.append(orm.getProperty(clazz.getName()))
		.append(" where ")
		.append(orm.getProperty("uid"))
		.append("=?");
		System.out.println("sql:"+sb);
		return sb.toString();
	}

	private String selectAll(Class clazz){
		StringBuffer sb = new StringBuffer();
		sb.append("select ")
				.append(orm.getProperty("property"))
				.append(" from ")
				.append(orm.getProperty(clazz.getName()));
		System.out.println("sql:"+sb);
		return sb.toString();
	}

	private String insert(Class clazz){
		String sb = "insert into "+orm.getProperty(clazz.getName())+"("+orm.getProperty("allP")+") values(?,?,?)";
		System.out.println("sql:"+sb);
		return sb;
	}

	private String update(Class clazz){
		String sb = "update "+orm.getProperty(clazz.getName())+" set score=? where name=?";
		System.out.println("sql:"+sb);
		return sb;
	}

	private String delete(Class clazz){
		String sb = "delete from "+orm.getProperty(clazz.getName())+" where uid=?";
		System.out.println("sql:"+sb);
		return sb;
	}

	public Object load(Class clazz, Serializable uid) {
		String sql = selectByUId(clazz);
		Object o =  this.jdbcTemplate.queryForObject(sql, new Object[] {uid}, clazz);
//		System.out.println("get object:"+o);
		return o;
	}

	public List<Object> load(Class clazz){
		String sql = selectAll(clazz);
		return jdbcTemplate.queryForObject(sql, clazz);
	}

	public Object load(Class clazz, User user) {
		String sql = insert(clazz);
		Object o =  this.jdbcTemplate.queryForObject(sql, new Object[] {user.getUid(),user.getName(),user.getScore()});
		return o;
	}

	public Object loadD(Class clazz, Serializable uid) {
		String sql = delete(clazz);
		Object o =  this.jdbcTemplate.queryForObject(sql, uid);
		return o;
	}

	public Object loadU(Class clazz, User user) {
		String sql = update(clazz);
		Object o =  this.jdbcTemplate.queryForObject(sql, new Object[] {user.getScore(), user.getName()});
		return o;
	}

}
