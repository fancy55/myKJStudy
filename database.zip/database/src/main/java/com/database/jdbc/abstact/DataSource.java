package com.database.jdbc.abstact;

import java.sql.Connection;

public abstract class DataSource {
	public abstract Connection getConnection();
}
