package com.database.jdbc.inteface;

import java.sql.PreparedStatement;

public interface PreparedStatementSetter {
	void setParameter(PreparedStatement preparedStatement);
}
