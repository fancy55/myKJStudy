package com.database.model;

public class User {
    Object uid;
    Object name;
    Object score;

    public User() {
    }

    public User(Object uid, Object name, Object score) {
        this.uid = uid;
        this.name = name;
        this.score = score;
    }

    public Object getUid() {
        return uid;
    }

    public void setUid(Object uid) {
        this.uid = uid;
    }

    public Object getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Object getScore() {
        return score;
    }

    public void setScore(Object score) {
        this.score = score;
    }
}
