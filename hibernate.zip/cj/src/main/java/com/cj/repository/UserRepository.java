package com.cj.repository;

import com.cj.model.User;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import javax.transaction.Transactional;

@Repository
public interface UserRepository extends CrudRepository<User, Long> {
    @Query(value = "select * from user", nativeQuery = true)
    User[] findAllUser();

    @Query(value = "select * from user where name=:name", nativeQuery = true)
    User[] findUserByName(@Param("name") String name);

    @Query(value = "insert into user values(?,?,?)", nativeQuery = true)
    @Transactional
    @Modifying
    int insertUser2(@Param("uid") Long uid,@Param("name") String name,@Param("score") int score);

    @Modifying
    @Transactional
    @Query(value = "update user set score=:score where name=:name", nativeQuery = true)
    void upDateScore(@Param("name") String name,@Param("score") int score);

    @Modifying
    @Transactional
    @Query(value = "delete from user  where name=:name", nativeQuery = true)
    void deleteUserByName(@Param("name") String name);
}
