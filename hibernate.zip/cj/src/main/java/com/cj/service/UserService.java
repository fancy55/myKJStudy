package com.cj.service;

import com.cj.model.User;
import com.cj.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class UserService {

    @Autowired
    UserRepository userRepository;

    public User[] getAllUser(){
        return userRepository.findAllUser();
    }

    public User[] getUserByName(String name){
        return userRepository.findUserByName(name);
    }

    public int addUser2(User user){
        return userRepository.insertUser2(user.getUid(),user.getName(),user.getScore());
    }

    public void updateScore(String name, int score){
        userRepository.upDateScore(name, score);
    }

    public void deleteUserWithName(String name){
        userRepository.deleteUserByName(name);
    }
}
