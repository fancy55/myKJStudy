package com.cj.controller;

import com.alibaba.fastjson.JSONArray;
import com.cj.model.User;
import com.cj.repository.UserRepository;
import com.cj.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/user")
public class UserController {
    @Autowired
    UserService userService;

    Map<String, Object> map = new HashMap<>();

    @GetMapping("all")
    public Map<String, Object> getAll(){
        map.put("all",userService.getAllUser());
        return map;
    }

    @GetMapping("byName")
    public Map<String, Object> getByName(String name){
        map.put("byName",userService.getUserByName(name));
        return map;
    }

    @PostMapping("add2")
    @ResponseBody
    public String add2(String msg){
        if(userService.addUser2(JSONArray.parseObject(msg, User.class)) == 1)return "增加成功";
        return "增加失败";
    }

    @PostMapping("update")
    public void updateScore(int score, String name){
        userService.updateScore(name,score);
    }

    @PostMapping("delete")
    public void delete(String name){
        userService.deleteUserWithName(name);
    }
}
